<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modern Home</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            background: rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }
        button {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            background: #ff7eb3;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #ff4f9a;
        }
    </style>
</head>
<body>

<div class="card">
    <h1>Welcome, <?php echo "User"; ?> 👋</h1>
    <p><?php echo date("l, d M Y"); ?></p>
    <button onclick="alert('Hello from PHP UI!')">Click Me</button>
</div>

</body>
</html>